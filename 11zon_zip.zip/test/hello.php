<?php 
$mysql = new mysqli('localhost', 'root', '','test-reg');
$result = $mysql->query("SELECT * FROM `news`");
$data = $result->fetch_all();

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
   <?php
   foreach($data as $item){
    ?>
    <div class="news">
        <div class="news-title"><?php echo $item[1] ?></div>
        <div class="news-description"><?php echo $item[2] ?></div>
        <div class="news-date"><?php echo $item[3] ?></div>
        <div class="btns">
            <a href="edit.php?id=<?php echo $item[0] ?>">Редактировать</a>
            <a href="delite.php?id=<?php echo $item[0] ?>">Удалить</a>
        </div>
    </div>
    <?php
   }
   ?>
<form class="add" action="add.php" method="post">
    <input type="text" placeholder="Название новости" name="title">
    <input type="text" placeholder="Содержание" name="description">
    <input type="text" placeholder="Дата" name="date">
    <button>Отправить</button>
</form>

  
</body>
</html>