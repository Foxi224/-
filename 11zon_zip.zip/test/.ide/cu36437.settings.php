<?php
/*|{"cu36437":{"codiad.username":"cu36437"}}|*/
?>