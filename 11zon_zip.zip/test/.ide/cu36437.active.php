<?php
/*|{"1":{"username":"cu36437","path":"\/home\/c\/cu36437\/public_html\/index.php","focused":false}}|*/
?>