<!-- <?php
$site_name = 'info';
// UTM
$utm_source = isset($_REQUEST["utm_source"]) ? $_REQUEST["utm_source"] : ' ';
$utm_medium = isset($_REQUEST["utm_medium"]) ? $_REQUEST["utm_medium"] : ' ';
$utm_campaign = isset($_REQUEST["utm_campaign"]) ? $_REQUEST["utm_campaign"] : ' ';
$utm_term = isset($_REQUEST["utm_term"]) ? $_REQUEST["utm_term"] : ' ';
$utm_content = isset($_REQUEST["utm_content"]) ? $_REQUEST["utm_content"] : ' ';
//
$block = isset($_REQUEST["block"]) ? $_REQUEST["block"] : ' ';
$source = isset($_REQUEST["source"]) ? $_REQUEST["source"] : ' ';
$placement = isset($_REQUEST["placement"]) ? $_REQUEST["placement"] : ' ';
$position = isset($_REQUEST["position"]) ? $_REQUEST["position"] : ' ';
$network = isset($_REQUEST["network"]) ? $_REQUEST["network"] : ' ';
?> --><!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1"><!--metatextblock--><title>Фабрика LOSK | Стирка
    ковров | Химчистка мебели | Чита | Фабрика ЛОСК</title>
<!--    Время жизни кэша-->
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="max-age=3600, must-revalidate" />
    <meta name="description"
          content="Профессиональная химчистка ковров. Забор и доставка ковров. Стираем ковры на фабрике. Современное турецкое оборудование. Чистка мягкой мебели на дому. Чита">
    <meta name="keywords"
          content="стирка пледов, химчистка пледа, химчистка пледа цена, где постирать плед, где можно постирать плед, чистка пледа, где постирать большой плед, стирка пледа цена, сколько стоит химчистка пледа, химчистка постирать плед, сколько стоит постирать плед, стирка пледа в прачечной, чистка дивана, химчистка дивана на дому, чистка диванов на дому, чистка дивана цена, чистка диванов на дому цена, чистка ткани дивана, чистка одеял, химчистка пуховых одеял, химчистка ватного одеяла, чистка пуховых одеял, химчистка одеяла стоимость, сколько стоит химчистка одеяла, химчистка одеяла шерсти, сдать одеяло в химчистку, почистить стулья, химчистка стульев, чистка стульев, химчистка матраса, чистка матрасов, химчистка матраса на дому, чистка матрасов на дому, чистка ковров, химчистка ковров, стирка ковров, чистка ковров с вывозом, химчистка ковра цена, чистка ковров цена, постирать ковер, химчистка ковров с доставкой, химчистка ковров с забором, химчистка ковров с забором и доставкой, чистка ковров на дому, чистка ковров недорого, стирка ковров цена, химчистка ковров на дому, мытье ковров, стирка ковров с вывозом, адрес химчистки ковров, химчистка ковров с вывозом, чистка ковров с вывозом недорого, чистка ковров с доставкой, чистка ковров телефон, где почистить ковер, фабрика чистки ковров, быстро почистить ковры, стирка ковров с доставкой, стирка паласов, адрес чистки ковров, химчистка ковров недорого, чистка ковров с вывозом цены, ковер мягкий чистка, где постирать ковер, химчистка ковров цены адреса, телефоны стирки ковров, очистка ковров, ковровая чистка, химчистка покрывало, стирка покрывала, чистка покрывал, химчистка покрывала цена, химчистка чехлов, чистка чехлов, химчистка чехлов от дивана, химчистка кресел, чистка кресел, чистка мебели, химчистка мягкой мебели, чистка мягкой мебели, химчистка мебели на дому, чистка мебели на дому, химчистка мягкой мебели на дому, домашняя чистка мебели, чистка мягкой мебели на дому, чистка мебели цена, ковер, постирать, стирка, химчистка, чистка, лоск, losk">
    <meta property="og:url" content="https://fabrika-losk.ru">
    <meta property="og:title" content="Фабрика &quot;LOSK&quot;">
    <meta property="og:description"
          content="Химчистка ковров. Забор и доставка ковров. Стираем  ковры на фабрике. Современное турецкое оборудование.">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://fabrika-losk.ru/img/logo.svg">
    <link rel="canonical" href="index.php"><!--/metatextblock-->
    <!-- <meta property="fb:app_id" content="257953674358265" /> -->
    <meta name="format-detection" content="telephone=no">
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <link rel="icon" href="https://fabrika-losk.ru/favicon.ico" type="image/x-icon"><!-- Assets -->
    <link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.css">
    <link rel="stylesheet" href="/css/style.min.css" type="text/css" media="all">
    <script src="/vendor/jquery/jquery-1.10.2.min.js"></script>
    <!--   <script src="/vendor/lazyload-1.3.min.js" charset="utf-8"></script> --><!-- Yandex.Metrika counter -->
<!--    <script type="text/javascript">(function (m, e, t, r, i, k, a) {-->
<!--        m[i] = m[i] || function () {-->
<!--            (m[i].a = m[i].a || []).push(arguments)-->
<!--        };-->
<!--        m[i].l = 1 * new Date();-->
<!--        k = e.createElement(t), a = e.getElementsByTagName(t)[0], k.async = 1, k.src = r, a.parentNode.insertBefore(k,-->
<!--            a)-->
<!--    })-->
<!--    (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");-->

<!--    ym(72563776, "init", {-->
<!--        clickmap: true,-->
<!--        trackLinks: true,-->
<!--        accurateTrackBounce: true,-->
<!--        webvisor: true-->
<!--    });</script>-->
<!--    <noscript>-->
<!--        <div><img src="https://mc.yandex.ru/watch/72563776" style="position: absolute; left: -9999px;" alt=""></div>-->
<!--    </noscript>&lt;!&ndash; /Yandex.Metrika counter &ndash;&gt;&lt;!&ndash; Global site tag (gtag.js) - Google Analytics &ndash;&gt;-->
<!--    <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-81497730-48"></script>-->


    <script>window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }

    gtag('js', new Date());

    gtag('config', 'UA-81497730-48');</script>
    <script>(function (w, c) {
        (w[c] = w[c] || []).push(function () {
            new zTracker({
                "id": "2b9e11e0e5247ec93f0052a2cdbef3ea6282",
                "metrics": {
                    "metrika": "72563776",
                    "ga": "UA-81497730-48"
                }
            });
        });
    })(window, "zTrackerCallbacks");</script>
    <script async id="zd_ct_phone_script" src="https://my.zadarma.com/js/ct_phone.min.js"></script>
</head>
<body class="" style="margin: 0;">
<!-- Yandex.Metrika counter 1 -->
<script type="text/javascript" >
    (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
        m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
    (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

    ym(87438259, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true
    });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/87438259" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter 1 -->
<progress value="0">
    <div class="progress-container"><span class="progress-bar"></span></div>
</progress>
<header class="header header--desktop">
    <div class="section__wrapper header__wrapper">
        <div class="header__logo"><img src="/img/logo.svg" class="logo" alt="Логотип" width="115" height="46"></div>
        <nav class="nav scrollto">
            <ul class="nav__list">
                <li class="nav__list-item"><a class="nav__link" href="#calculator">Цены</a></li>
                <li class="nav__list-item"><a class="nav__link" href="#delivery">Доставка</a></li>
                <li class="nav__list-item"><a class="nav__link" href="#video">Видео</a></li>
                <li class="nav__list-item"><a class="nav__link" href="#photo">Фото</a></li>
                <li class="nav__list-item"><a class="nav__link" href="#questions">Вопросы</a></li>
            </ul>
        </nav>
        <div class="nav__phone"><p class="nav__text">приём заказов с 9:00 до 21:00</p><a class="nav__tel zphone"
                                                                                         href="tel:+79248080808">+7
            (924) 808-08-08</a></div>
    </div>
</header>
<div id="follower" class="header header--mobile">
    <div class="header__wrapper">
        <div class="header__menu">
            <div class="menu__wrapper"><a class="menu-toggle" href="#"><span></span></a></div>
            <div class="header__logo"><img src="/img/logo.svg" class="logo" alt="Логотип" width="100" height="40"></div>
            <div class="header__phones"><p class="header__text">приём заказов с 9:00 до 21:00</p><a
                    class="header__tel zphone" href="tel:+73022383132">+7 (3022) 38-31-32</a></div>
        </div>
        <div class="header__nav">
            <nav class="nav">
                <ul class="main-navigation">
                    <li class="scrollto"><a class="" href="#calculator" title="">Цены</a></li>
                    <li class="scrollto"><a class="" href="#delivery" title="">Доставка</a></li>
                    <li class="scrollto"><a class="" href="#video" title="">Видео</a></li>
                    <li class="scrollto"><a class="" href="#photo" title="">Фото</a></li>
                    <li class="scrollto"><a class="" href="#questions" title="">Вопросы</a></li>
                </ul>
                <a href="#order" class="nav__btn topopup min popup-with-form btn"
                   action="Заказ звонка | Мобильная версия">Заказать звонок</a></nav>
        </div>
    </div>
</div>
<main>
    <section class="main">
        <div class="main__bg-filter">
            <div class="section__wrapper">
                <div class="main__content scrollto"><h1 class="main__title">Профессиональная стирка ковров на фабрике
                    "LOSK"</h1>
                    <p class="main__text">Круглый год. Любые ковры. Турецкое оборудование.</p><a class="main__btn btn"
                                                                                                 href="#calculator">Рассчитать
                        стирку</a></div>
            </div>
        </div>
    </section>
    <section class="warranty">
        <div class="section__wrapper"><h2 class="section__title">Гарантируем вам</h2>
            <ul class="warranty__list">
                <li class="warranty__list-item warranty__list-item--integrity">Целостность ткани и декора</li>
                <li class="warranty__list-item warranty__list-item--durability">Долговечность изделия</li>
                <li class="warranty__list-item warranty__list-item--smell">Удаление грязи и запахов</li>
                <li class="warranty__list-item warranty__list-item--microbe">Уничтожение бактерий</li>
                <li class="warranty__list-item warranty__list-item--color">Сохранение цвета и яркости</li>
                <li class="warranty__list-item warranty__list-item--smudge">Выведение любых пятен *</li>
            </ul>
            <div class="warranty__footnote">* кроме случаев, когда пятно застарелое или закреплено бытовым очистителем
            </div>
        </div>
    </section>
    <section class="calculator" id="calculator">
        <div class="section__wrapper"><h2 class="section__title">Рассчитайте примерную стоимость стирки ковра</h2>
            <div class="calculator__wrapper">
                <div class="carpet">
                    <div class="carpet__box" style="width: 196px;">
                        <div class="carpet__center"></div>
                    </div>
                    <div class="calculator__range-box">
                        <div class="range__wrapper"><label class="range__label" for="range"><span id="size"
                                                                                                  class="size">28</span>
                            <span>м²</span></label> <input id="range" type="range" class="calculator__range" min="1"
                                                           max="30" step="1" name="area" value="28"></div>
                    </div>
                </div>
                <div class="calculator__body">
                    <div class="calculator__total">примерная стоимость: <span class="total" id="total">8400</span>
                        <span class="rub">₽</span></div>
                    <div class="custom-control custom-checkbox row d-flex justify-content-center mb-3">
                        <div class="calculator__field" style="visibility: visible;"><input type="checkbox" id="smell"
                                                                                           name="check"
                                                                                           class="visually-hidden calculator__checkbox">
                            <label class="calculator__label calculator__label--checkbox" for="smell">
                                <div class="calculator__service">Выведение запаха</div>
                                <div class="calculator__description">+20% от стоимости</div>
                            </label></div>
                        <div class="calculator__field" style="visibility: visible;"><input placeholder="0" max="99"
                                                                                           type="number" maxlength="2"
                                                                                           id="gum" name="gum"
                                                                                           class="calculator__input">
                            <div class="calculator__label-box"><label class="calculator__label calculator__label--input"
                                                                      for="gum">Удаление жвачки, пластилина</label>
                                <div class="calculator__description">+50 ₽ / единица загрязнения</div>
                            </div>
                        </div>
                        <div class="calculator__field" style="visibility: visible;">
                            <div class="calculator__label-box"><label class="calculator__label calculator__label--input"
                                                                      for="gum">Стирка грязезащитных ковров</label>
                                <div class="calculator__description">300₽ м²</div>
                            </div>
                        </div>
                    </div>
                    <div class="calculator__total-box"><a href="#order_calc" action="Рассчитать стоимость"
                                                          class="calculator__button btn popup-with-form">Заказать
                        стирку</a></div>
                </div>
            </div>
        </div>
    </section>
    <section class="delivery" id="delivery">
        <div class="section__wrapper"><h2 class="section__title">Информация о доставке</h2>
            <div class="delivery__wrapper">
                <div class="delivery__map">
                    <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A2a412d0514efcb10f63980c41f65ec777bb852248ba454afd916a4e042a95532&amp;width=100%25&amp;height=350&amp;lang=ru_RU&amp;scroll=true"></script>
<!--                    <script type="text/javascript" charset="utf-8" async=""-->
<!--                            src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A9bc7186baaed57a33418e4d78b992ab5b4434277f72c64b05f5cc64fe7123e43&amp;width=100%&amp;height=100%&amp;lang=ru_RU&amp;scroll=true"></script>-->
                </div>
                <ul class="delivery__list">
                    <li class="delivery__list-item"><p>Забор и доставка ковров</p>
                        <ul class="delivery__color-list">
                            <li class="delivery__color-list-item">
                                <div class="delivery__color delivery__color--green"></div>
                                <p class="delivery__text">бесплатно</p></li>
                        </ul>
                    </li>
                    <li class="delivery__list-item"><p>Отдалённые районы</p>
                        <ul class="delivery__color-list">
                            <li class="delivery__color-list-item">
                                <div class="delivery__color delivery__color--blue"></div>
                                <p class="delivery__text">150 ₽</p></li>
                            <li class="delivery__color-list-item">
                                <div class="delivery__color delivery__color--violet"></div>
                                <p class="delivery__text">200 ₽</p></li>
                            <li class="delivery__color-list-item">
                                <div class="delivery__color delivery__color--yellow"></div>
                                <p class="delivery__text">250 ₽</p></li>
                        </ul>
                    </li>
                    <li class="delivery__list-item"><p>Бережная перевозка ковров<br>на новом фургоне Lada Largus<br>с
                        9:00 до 21:00</p></li>
                </ul>
            </div>
        </div>
    </section>
    <div id="example">
        <section class="portfolio" id="photo">
            <div class="section__wrapper portfolio__container">
                <div class="section__title portfolio__main-title">Результаты нашей работы</div>
                <div class="portfolio__slider">
                    <carousel-3d :controls-visible="true" :controls-prev-html="''" :controls-next-html="''"
                                 :controls-width="50" :controls-height="50" :clickable="true" :autoplay="false"
                                 :perspective="0" :inversescaling="196" :autoplay-timeout="5000" :display="3"
                                 :width="458" :height="366">
                        <slide :index="slide.id" v-for="slide in slidesPotfolio" :key="slide.id">
                            <div class="slider__slide icon"><a :href="slide.imgBig" data-fancybox="portfolio"
                                                               class="portfolio__item-img slider__link slider__link--portfolio disabled"><img
                                    :src="slide.img"></a></div>
                        </slide>
                    </carousel-3d>
                </div>
                <a class="btn popup-with-form" action="Хочу так же! | Блок фото слайдер" href="#portfolio-form">Хочу так
                    же!</a></div>
        </section>
        <section class="video" id="video">
            <div class="section__wrapper portfolio__container">
                <div class="section__title portfolio__main-title">Ваш ковёр пройдёт&nbsp;<br class="desktop--hidden">6
                    этапов стирки
                </div>
                <div class="video__slider">
                    <carousel-3d :controls-visible="true" :controls-prev-html="''" :controls-next-html="''"
                                 :controls-width="50" :controls-height="50" :clickable="true" :autoplay="false"
                                 :perspective="0" :inversescaling="196" :autoplay-timeout="5000" :display="1"
                                 :width="798" :height="448">
                        <slide :index="slide.id" v-for="slide in slidesVideo" :key="slide.id">
                            <div class="slider__slide icon"><a :href="slide.video" data-fancybox="video"
                                                               data-width="854" data-height="480"
                                                               class="video__item-img slider__link slider__link--video disabled"><img
                                    :src="slide.img"></a></div>
                        </slide>
                    </carousel-3d>
                </div>
            </div>
        </section>
        <section class="steps">
            <div class="section__wrapper steps__container">
                <div class=""><h2 class="section__title steps__main-title">Этапы стирки</h2>
                    <ul class="accordeon">
                        <li class="steps__item accordeon__item"><img class="steps__img" width="210" height="140"
                                                                     src="/img/step_0.webp" alt="Дефектовка ковра">
                            <div class="steps__wrap"><h3 class="steps__title">0 этап</h3>
                                <h3 class="steps__title">Дефектовка ковра</h3>
                                <p class="steps__description accordeon__description">– при приеме ковра технолог измерит
                                    точный размер, определит наличие дефектов, постороннего запаха, состав ковра. В
                                    случае, несовпадений данных, клиент будет уведомлён</p></div>
                        </li>
                        <li class="steps__item accordeon__item"><img class="steps__img" width="210" height="140"
                                                                     src="/img/step_1.webp"
                                                                     alt="Пылевыбивальный станок">
                            <div class="steps__wrap"><h3 class="steps__title">1 этап</h3>
                                <h3 class="steps__title">Пылевыбивальный станок</h3>
                                <p class="steps__description accordeon__description">–осуществляет сухую очистка ковра,
                                    оборудование деликатно выбивает всю накопившуюся пыль, крошки, песок и другие
                                    нерастворимые частицы из вашего ковра</p></div>
                        </li>
                        <li class="steps__item accordeon__item"><img class="steps__img" width="210" height="140"
                                                                     src="/img/step_2.webp" alt="Ковромоечный комплекс">
                            <div class="steps__wrap"><h3 class="steps__title">2 этап</h3>
                                <h3 class="steps__title">Ковромоечный комплекс</h3>
                                <p class="steps__description accordeon__description">– 8 роторных щеток идеально чисто
                                    простирывают каждый миллиметр вашего ковра, далее идет ополаскивание для полного
                                    выведения моющего средства</p></div>
                        </li>
                        <li class="steps__item accordeon__item"><img class="steps__img" width="210" height="140"
                                                                     src="/img/step_3.webp" alt="Центрифуга">
                            <div class="steps__wrap"><h3 class="steps__title">3 этап</h3>
                                <h3 class="steps__title">Центрифуга</h3>
                                <p class="steps__description accordeon__description">– бережный отжим на скорости 1200
                                    оборотов в минуту, позволяет терять до 90% влаги. Это сокращает время высыхания
                                    ковра и предотвращает появления запаха сырости</p></div>
                        </li>
                        <li class="steps__item accordeon__item"><img class="steps__img" width="210" height="140"
                                                                     src="/img/step_4.webp" alt="Сушильная камера">
                            <div class="steps__wrap"><h3 class="steps__title">4 этап</h3>
                                <h3 class="steps__title">Сушильная камера</h3>
                                <p class="steps__description accordeon__description">– оборудована осушителями и
                                    вентиляторами, для создания специального микроклимата, без попадания газов и прямых
                                    солнечных лучей</p></div>
                        </li>
                        <li class="steps__item accordeon__item"><img class="steps__img" width="210" height="140"
                                                                     src="/img/step_5.webp" alt="Финишная обработка">
                            <div class="steps__wrap"><h3 class="steps__title">5 этап</h3>
                                <h3 class="steps__title">Финишная обработка</h3>
                                <p class="steps__description accordeon__description">– 4 роторные турбощетки расчесывают
                                    и поднимают ворс ковра, а также убирают остатки шерсти и волос (если таковые
                                    имеются)</p></div>
                        </li>
                        <li class="steps__item accordeon__item"><img class="steps__img" width="210" height="140"
                                                                     src="/img/step_6.webp"
                                                                     alt="Упаковка в пленку для транспортировки">
                            <div class="steps__wrap"><h3 class="steps__title">6 этап</h3>
                                <h3 class="steps__title">Упаковка ковра в плёнку</h3>
                                <p class="steps__description accordeon__description">– позволяет исключить попадание
                                    грязи и пыли на ковер во время транспортировки</p></div>
                        </li>
                    </ul>
                    <div class="steps__footer"><p class="steps__text">В России единицы фабрик<br
                            class="desktop--hidden">&nbsp;с&nbsp;<span class="mobile--hidden">подобным</span><span
                            class="desktop--hidden">современным</span> оборудованием.&nbsp;<br class="desktop--hidden">Закажите
                        качественную стирку ковра!</p><a class="steps__btn btn popup-with-form"
                                                         action="Заказать стирку ковра | Блок этапы" href="#order">Заказать</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="reviews" id="reviews">
            <div class="section__wrapper reviews__container"><h2 class="section__title reviews__main-title">Отзывы наших
                клиентов</h2>
                <div class="reviews__slider">
                    <carousel-3d :controls-visible="true" :controls-prev-html="''" :controls-next-html="''" :space="220"
                                 :controls-width="50" :controls-height="50" :clickable="true" :autoplay="false"
                                 :perspective="0" :inversescaling="296" :animationspeed="500" :autoplay-timeout="5000"
                                 :display="3" :width="250" :height="519">
                        <slide :index="slide.id" v-for="slide in slidesFeedback" :key="slide.id">
                            <div class="slider__slide icon"><a :href="slide.imgBig" data-fancybox="review"
                                                               class="reviews__item-img slider__link slider__link--reviews disabled"><img
                                    :src="slide.img"></a></div>
                        </slide>
                    </carousel-3d>
                </div>
            </div>
        </section>
        <section class="other-service" id="extra">
            <div class="section__wrapper">
                <div class="other-service__item"><p class="other-service__text">Химчистка мебели на дому</p>
                    <p class="other-service__price">от 200 ₽</p>
                    <ul class="other-service__list">
                        <li class="other-service__list-item">Матрасы</li>
                        <li class="other-service__list-item">Кресла</li>
                        <li class="other-service__list-item">Стулья</li>
                        <li class="other-service__list-item">Диваны</li>
                    </ul>
                    <div class="other-service__box">
                        <!-- <p class="other-service__text">Химчистка на дому</p><p class="other-service__price">от 200 ₽</p> -->
                        <p class="other-service__footnote">при заказе от 1000 ₽ выезд в подарок!</p><a
                            href="#other-service1" action="Заказать химчистку мебели" class="btn popup-with-form">Заказать</a>
                    </div><!-- <p class="other-service__footnote">выезд бесплатно при заказе от 1000 ₽</p> --></div>
                <div class="other-service__item"><p class="other-service__text">Стирка изделий на фабрике</p>
                    <p class="other-service__price">от 300 ₽</p>
                    <ul class="other-service__list">
                        <li class="other-service__list-item">Пледы</li>
                        <li class="other-service__list-item">Покрывала</li>
                        <li class="other-service__list-item">Одеяла</li>
                        <li class="other-service__list-item other-service__list-item--pillow desktop--hidden">Подушки
                        </li>
                    </ul>
                    <ul class="other-service__list">
                        <li class="other-service__list-item other-service__list-item--pillow mobile--hidden">Подушки
                        </li>
                        <li class="other-service__list-item other-service__list-item--cover">Чехлы</li>
                    </ul>
                    <div class="other-service__box"><p class="other-service__footnote">при заказе от 1000 ₽ доставка в
                        подарок!</p>
                        <!-- <p class="other-service__text">Стирка на фабрике</p><p class="other-service__price">от 300 ₽</p> -->
                        <a href="#other-service2" action="Заказать стирку доп. изделий" class="btn popup-with-form">Заказать</a>
                    </div><!-- <p class="other-service__footnote">доставка бесплатно при заказе от 1000 ₽</p> --></div>
            </div>
        </section>
        <section class="video2" id="video_2">
            <div class="section__wrapper portfolio__container">
                <div class="section__title portfolio__main-title">Видео с Фабрики Лоск</div>
                <div class="video__slider">
                    <carousel-3d :controls-visible="true" :controls-prev-html="''" :controls-next-html="''"
                                 :controls-width="50" :controls-height="50" :clickable="true" :autoplay="false"
                                 :perspective="0" :inversescaling="196" :display="1" :animationspeed="10" :width="798"
                                 :height="520">
                        <slide :index="slide.id" v-for="slide in slidesVideo2" :key="slide.id"><h2
                                class="slider__title">{{slide.title}}</h2>
                            <div class="slider__slide icon"><a :href="slide.video" data-fancybox="video"
                                                               data-width="854" data-height="520"
                                                               class="video__item-img slider__link slider__link--video disabled"><img
                                    :src="slide.img"></a></div>
                        </slide>
                    </carousel-3d>
                </div>
            </div>
        </section>
    </div>
    <section class="callback">
        <div class="section__wrapper">
            <div class="callback__wrapper"><h2 class="section__title">Закажите стирку ковра</h2>
                <p class="callback__description">Мы свяжемся с вами в течение 1 часа и рассчитаем стоимость</p></div>
            <div class="callback__form-wrapper">
                <form class="callback__form form">
                    <div class="callback__input-box">
                        <div class="callback__error callback__error--name"></div>
                        <input class="callback__input" type="text" name="request[Имя]" id="callback-name"
                               placeholder="Имя" required="" autocomplete="on"><label for="callback-name">&nbsp;</label>
                    </div>
                    <div class="callback__input-box">
                        <div class="callback__error callback__error--phone"></div>
                        <input class="callback__input" type="tel" name="request[Телефон]" id="tel-field"
                               placeholder="Телефон" required=""><label for="tel-field">&nbsp;</label></div>
                    <input name="cid" value="?" type="hidden"> <input name="utm_medium"
                                                                      value="<?php echo $utm_medium; ?>" type="hidden"
                                                                      class="utm_medium"> <input name="utm_source"
                                                                                                 value="<?php echo $utm_source; ?>"
                                                                                                 type="hidden"
                                                                                                 class="utm_source">
                    <input name="block" value="<?= $block; ?>" type="hidden"> <input name="placement"
                                                                                     value="<?= $placement; ?>"
                                                                                     type="hidden"> <input
                        name="utm_campaign" value="<?php echo $utm_campaign; ?>" type="hidden" class="utm_campaign">
                    <input name="utm_term" value="<?php echo $utm_term; ?>" type="hidden" class="utm_term"> <input
                        name="utm_content" value="<?php echo $utm_content; ?>" type="hidden" class="utm_content"> <input
                        name="position" value="<?php echo $position; ?>" type="hidden" class="position"> <input
                        name="network" value="<?php echo $network; ?>" type="hidden" class="network"> <input
                        type="hidden" name="source" value="<?php echo $source; ?>"> <input type="hidden" name="action"
                                                                                           value="Заказать стирку ковра | Блок звонок футер">
                    <input type="hidden" name="goal" value="application_with_forms">
                    <button class="form__btn callback__btn btn" type="submit" style="-webkit-appearance: none;">
                        <!--noindex-->Заказать звонок<!--/noindex--></button>
                </form>
            </div>
        </div>
    </section>
    <section class="faq" id="questions">
        <div class="section__wrapper"><h2 class="section__title faq__main-title">Часто задаваемые вопросы</h2>
            <ul class="faq__accordeon accordeon">
                <li class="faq__item accordeon__item"><h3 class="faq__title">Ковёр не потеряется?</h3>
                    <p class="faq__description accordeon__description">Нет. Риск потери ковра исключен. Все ковры при
                        поступлении ковра на фабрику обязательно маркируются. Вы можете не беспокоиться за сохранность
                        своего ковра!</p></li>
                <li class="faq__item accordeon__item"><h3 class="faq__title">Вы даёте гарантию полного&nbsp;<br>выведения
                    пятен и запахов?</h3>
                    <p class="faq__description accordeon__description">В 99% случаях мы справляемся с любыми
                        загрязнениями. 1% исключения составляют застарелые пятна и тот случай, когда до нас ковер
                        пытались неоднократно почистить самостоятельно, используя бытовые пятновыводители и очистители.
                        Выведение запаха также требует особого подхода. Дать гарантию 100% выведения пятна или запаха
                        невозможно. Поэтому, чем раньше Вы обратитесь к нам, тем больше шансов вернуть идеальный вид
                        Вашему ковру. Уверены, что если не отстираем мы, то не отстирает никто!</p></li>
                <li class="faq__item accordeon__item"><h3 class="faq__title">Ковёр не испортится?</h3>
                    <p class="faq__description accordeon__description">На нашей практике такого не случалось, так как мы
                        используем профессиональное оборудование и исключительно специализированные чистящие средства.
                        При поступлении ковров на фабрику, их обязательно осматривает дефектолог. С таким подходом,
                        ковер испортить просто невозможно!</p></li>
                <li class="faq__item accordeon__item"><h3 class="faq__title">Моющие средства безопасны?</h3>
                    <p class="faq__description accordeon__description">Моющие средства, используемые нами для стирки
                        гипоаллергенны и полностью безопасны для детей и животных.</p></li>
            </ul>
        </div>
    </section>
</main>
<footer class="footer">
    <div class="section__wrapper footer__info">
        <div class="footer__map" id="map"></div>
        <div class="contacts"><p class="contacts__name">Фабрика стирки ковров "LOSK"</p><a
                href="mailto:info@fabrika-losk.ru" class="contacts__email">info@fabrika-losk.ru</a> <a
                href="tel:+73022383132" class="zphone">+7 (3022) 38-31-32</a> <a href="tel:+79248080808"
                                                                                 class="utm_phone">+7 (924)
            808-08-08</a>
            <p class="contacts__text">Приём заказов с 9:00 до 21:00<br>без перерывов и выходных</p>
            <p class="contacts__text">г. Чита, ул. Генерала Белика д. 51<br>(проезд по улице Набережная)</p>
            <ul class="footer__social-list">
                <li class="footer__social-item footer__social-item--vk"><a class=""
                                                                           href="https://vk.com/stirka_kovrov_chita"
                                                                           target="_blank"></a></li>
                <li class="footer__social-item footer__social-item--insta"><a class=""
                                                                              href="https://instagram.com/stirka_kovrov_chita"
                                                                              target="_blank"></a></li>
                <li class="footer__social-item footer__social-item--ok"><a class=""
                                                                           href="https://ok.ru/group/57915994144918"
                                                                           target="_blank"></a></li>
            </ul>
        </div>
    </div>
    <div class="footer__logo"><a
            href="https://alpham.pro/?utm_source=fabrika-losk.ru&utm_medium=fabrika-losk.ru&utm_campaign=fabrika-losk.ru"><img
            src="/img/alpham-logo.svg" alt="" width="164" height="auto"></a><a class="footer__politics"
                                                                               href="/privacy-policy/index.html"
                                                                               target="_blank"
                                                                               field="tn_text_1603805485598">Политика
        конфиденциальности</a></div>
</footer>
<div class="modal-windows">
    <div class="hidden">
        <div class="popup-timer popup mfp-hide" id="popup-timer"><h2 class="popup-timer__title popup__title">Чистка
            подушек<br>на фабрике!</h2>
            <p class="popup-timer__subtitle">от 300 ₽</p>
            <form class="popup-timer__form form">
                <div class="callback__input-box">
                    <div class="callback__error callback__error--name"></div>
                    <input class="callback__input" type="text" name="request[Имя]" id="popup-timer-name"
                           placeholder="Имя" required="" autocomplete="on"><label for="popup-timer-name">&nbsp;</label>
                </div>
                <div class="callback__input-box">
                    <div class="callback__error callback__error--phone"></div>
                    <input class="callback__input" type="tel" name="request[Телефон]" id="popup-timer-tel"
                           placeholder="Телефон" required=""><label for="popup-timer-tel">&nbsp;</label></div>
                <input name="cid" value="?" type="hidden"> <input name="utm_medium" value="<?php echo $utm_medium; ?>"
                                                                  type="hidden" class="utm_medium"> <input
                    name="utm_source" value="<?php echo $utm_source; ?>" type="hidden" class="utm_source"> <input
                    name="block" value="<?= $block; ?>" type="hidden"> <input name="placement"
                                                                              value="<?= $placement; ?>" type="hidden">
                <input name="utm_campaign" value="<?php echo $utm_campaign; ?>" type="hidden" class="utm_campaign">
                <input name="utm_term" value="<?php echo $utm_term; ?>" type="hidden" class="utm_term"> <input
                    name="utm_content" value="<?php echo $utm_content; ?>" type="hidden" class="utm_content"> <input
                    name="position" value="<?php echo $position; ?>" type="hidden" class="position"> <input
                    name="network" value="<?php echo $network; ?>" type="hidden" class="network"> <input type="hidden"
                                                                                                         name="source"
                                                                                                         value="<?php echo $source; ?>">
                <input type="hidden" name="title" value=""> <input type="hidden" name="action"
                                                                   value="Окно по таймеру | Чистка Подушек"> <input
                    type="hidden" name="goal" value="application_with_forms">
                <button class="form__btn order__btn btn" type="submit" style="-webkit-appearance: none;"><!--noindex-->
                    Заказать<!--/noindex--></button>
            </form>
        </div>
    </div>
    <div class="hidden">
        <div class="order popup mfp-hide" id="portfolio-form">
            <form class="order__form form">
                <div class="callback__input-box">
                    <div class="callback__error callback__error--name"></div>
                    <input class="callback__input" type="text" name="request[Имя]" id="portfolio-name" placeholder="Имя"
                           required="" autocomplete="on"><label for="portfolio-name">&nbsp;</label></div>
                <div class="callback__input-box">
                    <div class="callback__error callback__error--phone"></div>
                    <input class="callback__input" type="tel" name="request[Телефон]" id="portfolio-tel"
                           placeholder="Телефон" required=""><label for="portfolio-tel">&nbsp;</label></div>
                <input name="cid" value="?" type="hidden"> <input name="utm_medium" value="<?php echo $utm_medium; ?>"
                                                                  type="hidden" class="utm_medium"> <input
                    name="utm_source" value="<?php echo $utm_source; ?>" type="hidden" class="utm_source"> <input
                    name="block" value="<?= $block; ?>" type="hidden"> <input name="placement"
                                                                              value="<?= $placement; ?>" type="hidden">
                <input name="utm_campaign" value="<?php echo $utm_campaign; ?>" type="hidden" class="utm_campaign">
                <input name="utm_term" value="<?php echo $utm_term; ?>" type="hidden" class="utm_term"> <input
                    name="utm_content" value="<?php echo $utm_content; ?>" type="hidden" class="utm_content"> <input
                    name="position" value="<?php echo $position; ?>" type="hidden" class="position"> <input
                    name="network" value="<?php echo $network; ?>" type="hidden" class="network"> <input type="hidden"
                                                                                                         name="source"
                                                                                                         value="<?php echo $source; ?>">
                <input type="hidden" name="title" value=""> <input type="hidden" name="action"
                                                                   value="Хочу так же! | Блок фото слайдер"> <input
                    type="hidden" name="goal" value="application_with_forms">
                <button class="form__btn order__btn btn" type="submit" style="-webkit-appearance: none;"><!--noindex-->
                    Заказать стирку<!--/noindex--></button>
            </form>
        </div>
    </div>
    <div class="hidden">
        <div class="order popup mfp-hide" id="order">
            <form class="order__form form">
                <div class="callback__input-box">
                    <div class="callback__error callback__error--name"></div>
                    <input class="callback__input" type="text" name="request[Имя]" id="order-name" placeholder="Имя"
                           required="" autocomplete="on"><label for="order-name">&nbsp;</label></div>
                <div class="callback__input-box">
                    <div class="callback__error callback__error--phone"></div>
                    <input class="callback__input" type="tel" name="request[Телефон]" id="order-tel"
                           placeholder="Телефон" required=""><label for="order-tel">&nbsp;</label></div>
                <input name="cid" value="?" type="hidden"> <input name="utm_medium" value="<?php echo $utm_medium; ?>"
                                                                  type="hidden" class="utm_medium"> <input
                    name="utm_source" value="<?php echo $utm_source; ?>" type="hidden" class="utm_source"> <input
                    name="block" value="<?= $block; ?>" type="hidden"> <input name="placement"
                                                                              value="<?= $placement; ?>" type="hidden">
                <input name="utm_campaign" value="<?php echo $utm_campaign; ?>" type="hidden" class="utm_campaign">
                <input name="utm_term" value="<?php echo $utm_term; ?>" type="hidden" class="utm_term"> <input
                    name="utm_content" value="<?php echo $utm_content; ?>" type="hidden" class="utm_content"> <input
                    name="position" value="<?php echo $position; ?>" type="hidden" class="position"> <input
                    name="network" value="<?php echo $network; ?>" type="hidden" class="network"> <input type="hidden"
                                                                                                         name="source"
                                                                                                         value="<?php echo $source; ?>">
                <input type="hidden" name="title" value=""> <input type="hidden" name="action" value="Заказать"> <input
                    type="hidden" name="goal" value="application_with_forms">
                <button class="form__btn order__btn btn" type="submit" style="-webkit-appearance: none;"><!--noindex-->
                    Отправить<!--/noindex--></button>
            </form>
        </div>
    </div>
    <div class="hidden">
        <div class="order popup mfp-hide" id="order_calc">
            <form class="order__form form">
                <div class="callback__input-box">
                    <div class="callback__error callback__error--name"></div>
                    <input class="callback__input" type="text" name="request[Имя]" id="order-calc-name"
                           placeholder="Имя" required="" autocomplete="on"><label for="order-calc-name">&nbsp;</label>
                </div>
                <div class="callback__input-box">
                    <div class="callback__error callback__error--phone"></div>
                    <input class="callback__input" type="tel" name="request[Телефон]" id="order-calc-tel"
                           placeholder="Телефон" required=""><label for="order-calc-tel">&nbsp;</label></div>
                <input name="square" value="?" type="hidden"> <input name="stink" value="?" type="hidden"> <input
                    name="gum" value="0" type="hidden"> <input name="total" value="?" type="hidden"> <input name="cid"
                                                                                                            value="?"
                                                                                                            type="hidden">
                <input name="utm_medium" value="<?php echo $utm_medium; ?>" type="hidden" class="utm_medium"> <input
                    name="utm_source" value="<?php echo $utm_source; ?>" type="hidden" class="utm_source"> <input
                    name="block" value="<?= $block; ?>" type="hidden"> <input name="placement"
                                                                              value="<?= $placement; ?>" type="hidden">
                <input name="utm_campaign" value="<?php echo $utm_campaign; ?>" type="hidden" class="utm_campaign">
                <input name="utm_term" value="<?php echo $utm_term; ?>" type="hidden" class="utm_term"> <input
                    name="utm_content" value="<?php echo $utm_content; ?>" type="hidden" class="utm_content"> <input
                    name="position" value="<?php echo $position; ?>" type="hidden" class="position"> <input
                    name="network" value="<?php echo $network; ?>" type="hidden" class="network"> <input type="hidden"
                                                                                                         name="source"
                                                                                                         value="<?php echo $source; ?>">
                <input type="hidden" name="title" value=""> <input type="hidden" name="action"
                                                                   value="Заказать стирку ковра | Блок расчёт стоимости">
                <input type="hidden" name="goal" value="application_with_forms">
                <button class="form__btn order__btn btn" type="submit" style="-webkit-appearance: none;"><!--noindex-->
                    Отправить<!--/noindex--></button>
            </form>
        </div>
    </div>
    <div class="hidden">
        <div class="order popup mfp-hide" id="other-service1">
            <form class="order__form form">
                <div class="callback__input-box">
                    <div class="callback__error callback__error--name"></div>
                    <input class="callback__input" type="text" name="request[Имя]" id="service1-name" placeholder="Имя"
                           required="" autocomplete="on"><label for="service1-name">&nbsp;</label></div>
                <div class="callback__input-box">
                    <div class="callback__error callback__error--phone"></div>
                    <input class="callback__input" type="tel" name="request[Телефон]" id="service1-tel"
                           placeholder="Телефон" required=""><label for="service1-tel">&nbsp;</label></div>
                <label class="callback__select-box callback__error callback__error--object"><select required=""
                                                                                                    class="callback__select"
                                                                                                    name="request[Предмет]">
                    <option value="" disabled="disabled" style="display: none;" selected="selected">Выберите предмет
                    </option>
                    <option value="Матрасы">Матрасы</option>
                    <option value="Кресла">Кресла</option>
                    <option value="Стулья">Стулья</option>
                    <option value="Мягкая мебель">Мягкая мебель</option>
                </select></label> <input name="cid" value="?" type="hidden"> <input name="utm_medium"
                                                                                    value="<?php echo $utm_medium; ?>"
                                                                                    type="hidden" class="utm_medium">
                <input name="utm_source" value="<?php echo $utm_source; ?>" type="hidden" class="utm_source"> <input
                    name="block" value="<?= $block; ?>" type="hidden"> <input name="placement"
                                                                              value="<?= $placement; ?>" type="hidden">
                <input name="utm_campaign" value="<?php echo $utm_campaign; ?>" type="hidden" class="utm_campaign">
                <input name="utm_term" value="<?php echo $utm_term; ?>" type="hidden" class="utm_term"> <input
                    name="utm_content" value="<?php echo $utm_content; ?>" type="hidden" class="utm_content"> <input
                    name="position" value="<?php echo $position; ?>" type="hidden" class="position"> <input
                    name="network" value="<?php echo $network; ?>" type="hidden" class="network"> <input type="hidden"
                                                                                                         name="source"
                                                                                                         value="<?php echo $source; ?>">
                <input type="hidden" name="title" value=""> <input type="hidden" name="action"
                                                                   value="Заказать химчистку мебели"> <input
                    type="hidden" name="goal" value="application_with_forms">
                <button class="form__btn order__btn order__btn--other btn" type="submit"
                        style="-webkit-appearance: none;"><!--noindex-->Отправить<!--/noindex--></button>
            </form>
        </div>
        <div class="order popup mfp-hide" id="other-service2">
            <form class="order__form form">
                <div class="callback__input-box">
                    <div class="callback__error callback__error--name"></div>
                    <input class="callback__input" type="text" name="request[Имя]" id="service2-name" placeholder="Имя"
                           required="" autocomplete="on"><label for="service2-name">&nbsp;</label></div>
                <div class="callback__input-box">
                    <div class="callback__error callback__error--phone"></div>
                    <input class="callback__input" type="tel" name="request[Телефон]" id="service2-tel"
                           placeholder="Телефон" required=""><label for="service2-tel">&nbsp;</label></div>
                <label class="callback__select-box callback__error callback__error--object"><select required=""
                                                                                                    class="callback__select"
                                                                                                    name="request[Предмет]">
                    <option value="" disabled="disabled" style="display: none;" selected="selected">Выберите предмет
                    </option>
                    <option value="Пледы">Пледы</option>
                    <option value="Покрывала">Покрывала</option>
                    <option value="Одеяла">Одеяла</option>
                    <option value="Подушки">Подушки</option>
                    <option value="Чехлы">Чехлы</option>
                </select></label> <input name="cid" value="?" type="hidden"> <input name="utm_medium"
                                                                                    value="<?php echo $utm_medium; ?>"
                                                                                    type="hidden" class="utm_medium">
                <input name="utm_source" value="<?php echo $utm_source; ?>" type="hidden" class="utm_source"> <input
                    name="block" value="<?= $block; ?>" type="hidden"> <input name="placement"
                                                                              value="<?= $placement; ?>" type="hidden">
                <input name="utm_campaign" value="<?php echo $utm_campaign; ?>" type="hidden" class="utm_campaign">
                <input name="utm_term" value="<?php echo $utm_term; ?>" type="hidden" class="utm_term"> <input
                    name="utm_content" value="<?php echo $utm_content; ?>" type="hidden" class="utm_content"> <input
                    name="position" value="<?php echo $position; ?>" type="hidden" class="position"> <input
                    name="network" value="<?php echo $network; ?>" type="hidden" class="network"> <input type="hidden"
                                                                                                         name="source"
                                                                                                         value="<?php echo $source; ?>">
                <input type="hidden" name="title" value=""> <input type="hidden" name="action"
                                                                   value="Заказать стирку доп. изделий"> <input
                    type="hidden" name="goal" value="application_with_forms">
                <button class="form__btn order__btn order__btn--other btn" type="submit"
                        style="-webkit-appearance: none;"><!--noindex-->Отправить<!--/noindex--></button>
            </form>
        </div>
    </div>
</div>
<div class="hidden">
    <div class="popup mfp-hide" id="thanks">
        <div class="thanks__wrapper">
            <div class="thanks__svg">
                <svg width="85" height="85" viewBox="0 0 125 125" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule: evenodd; clip-rule: evenodd; stroke-linejoin: round; stroke-miterlimit: 2;"><g transform="matrix(1,0,0,1,-430.016,-61.3489)"><g transform="matrix(2.75949,0,0,2.75949,-191.838,-1018.54)"><path d="M245.224,423.39L244.506,422.579L236.276,413.95C235.942,413.601 235.956,413.046 236.305,412.713L237.571,411.505C237.921,411.172 238.475,411.185 238.808,411.534L245.224,418.261L256.94,405.978C257.273,405.629 257.827,405.615 258.177,405.949L259.443,407.157C259.793,407.49 259.806,408.044 259.472,408.394L245.942,422.579L245.224,423.39Z" style="fill: rgb(3, 114, 171);"></path><path
                        d="M245.224,423.39L244.506,422.579L236.276,413.95C235.942,413.601 235.956,413.046 236.305,412.713L237.571,411.505C237.921,411.172 238.475,411.185 238.808,411.534L245.224,418.261L256.94,405.978C257.273,405.629 257.827,405.615 258.177,405.949L259.443,407.157C259.793,407.49 259.806,408.044 259.472,408.394L245.942,422.579L245.224,423.39Z"
                        style="fill: rgb(3, 114, 171);"></path></g><g
                        transform="matrix(2.76227,0,0,2.76227,-1064.37,-190.018)"><path d="M563.5,91C575.918,91 586,101.082 586,113.5C586,125.918 575.918,136 563.5,136C551.082,136 541,125.918 541,113.5C541,101.082 551.082,91 563.5,91ZM563.5,94.62C573.92,94.62 582.38,103.08 582.38,113.5C582.38,123.92 573.92,132.38 563.5,132.38C553.08,132.38 544.62,123.92 544.62,113.5C544.62,103.08 553.08,94.62 563.5,94.62Z" style="fill: rgb(3, 114, 171);"></path></g></g></svg>
            </div>
            <p class="popup__text">Мы свяжемся с вами в течение 1 часа,<br>чтобы уточнить детали заказа</p>
            <p class="popup__text">Спасибо!</p></div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/smoothscroll/1.4.10/SmoothScroll.min.js" defer="defer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css"
      integrity="sha256-Vzbj7sDDS/woiFS3uNKo8eIuni59rjyNGtXfstRzStA=" crossorigin="anonymous">
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script src="/vendor/vue/vue-carousel-3d.min.js"></script>
<script src="/vendor/vue/vue.js"></script>
<script src="/js/slider.js"></script>
<script src="/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="/vendor/jquery.validate.min.js"></script>
<script src="/vendor/inputmask/jquery.inputmask.bundle.min.js"></script>
<script src="/vendor/jquery.arcticmodal/jquery.arcticmodal-0.3.min.js" defer="defer"></script>
<script src="/js/script.js"></script>
<script rel="preload" src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
<script>// Функция ymaps.ready() будет вызвана, когда
// загрузятся все компоненты API, а также когда будет готово DOM-дерево.
ymaps.ready(init);

function init() {
    // Создание карты.
    // https://tech.yandex.ru/maps/doc/jsapi/2.1/dg/concepts/map-docpage/
    var myMap = new ymaps.Map("map", {
        // Координаты центра карты.
        // Порядок по умолчнию: «широта, долгота».
        center: [52.047765, 113.464379],
        // Уровень масштабирования. Допустимые значения:
        // от 0 (весь мир) до 19.
        zoom: 10.8,
        // Элементы управления
        // https://tech.yandex.ru/maps/doc/jsapi/2.1/dg/concepts/controls/standard-docpage/
        controls: [
            "zoomControl", // Ползунок масштаба
            "fullscreenControl" // Полноэкранный режим
        ]
    }, {
        suppressMapOpenBlock: true,
    });

    collection = new ymaps.GeoObjectCollection({}, {
        iconLayout: 'default#image',
        iconImageHref: '/img/pin.svg',
        iconImageSize: [35, 60],
        iconImageOffset: [-10, -30]
    });

    // Добавление метки
    // https://tech.yandex.ru/maps/doc/jsapi/2.1/ref/reference/Placemark-docpage/
    var myPlacemark = new ymaps.Placemark(
        [52.046299, 113.461874], {
            // Хинт показывается при наведении мышкой на иконку метки.
            hintContent: "г. Чита, ул. Генерала Белика д. 51",
            // Балун откроется при клике по метке.
            balloonContent: "<div style='text-align: center;'>Фабрика стирки ковров «LOSK»<br> г. Чита<br> ул. Генерала Белика д. 51<br> 8 (3022) 38-31-32"
        }, {
            // Опции.
            // Необходимо указать данный тип макета.
            iconLayout: 'default#image',
            // Своё изображение иконки метки.
            iconImageHref: '/img/pin.svg',
            // Размеры метки.
            iconImageSize: [51, 61],
            // Смещение левого верхнего угла иконки относительно
            // её "ножки" (точки привязки).
            iconImageOffset: [-25, -60]
        }
    );

    // После того как метка была создана, добавляем её на карту.
    myMap.geoObjects.add(myPlacemark);
    myMap.behaviors.disable("scrollZoom");
    //myMap.behaviors.disable("drag");
    // myMap.behaviors.disable("multiTouch");
}</script>
</body>
</html>
