new Vue({
  el: "#example",
  data: {
    isAutoplay: false,
    slidesPotfolio: {
      0: {
        id: 0,
        img: "/img/slider/slider1_3.png",
        webp: "/img/slider/slider1_3.webp",
        imgBig: "/img/slider/slider1_3_b.png",
      },
      1: {
        id: 1,
        img: "/img/slider/slider1_2.png",
        webp: "/img/slider/slider1_2.webp",
        imgBig: "/img/slider/slider1_2_b.png",
      },
      2: {
        id: 2,
        img: "/img/slider/slider1_1.png",
        webp: "/img/slider/slider1_1.webp",
        imgBig: "/img/slider/slider1_1_b.png",
      },
      3: {
        id: 3,
        img: "/img/slider/slider1_4.png",
        webp: "/img/slider/slider1_4.webp",
        imgBig: "/img/slider/slider1_4_b.png",
      },
      4: {
        id: 4,
        img: "/img/slider/slider1_5.png",
        webp: "/img/slider/slider1_5.webp",
        imgBig: "/img/slider/slider1_5_b.png",
      },
      5: {
        id: 5,
        img: "/img/slider/slider1_6.png",
        webp: "/img/slider/slider1_6.webp",
        imgBig: "/img/slider/slider1_6_b.png",
      },
      6: {
        id: 6,
        img: "/img/slider/slider1_7.png",
        webp: "/img/slider/slider1_7.webp",
        imgBig: "/img/slider/slider1_7_b.png",
      },
      7: {
        id: 7,
        img: "/img/slider/slider1_8.png",
        webp: "/img/slider/slider1_8.webp",
        imgBig: "/img/slider/slider1_8_b.png",
      },
      8: {
        id: 8,
        img: "/img/slider/slider1_9.png",
        webp: "/img/slider/slider1_9.webp",
        imgBig: "/img/slider/slider1_9_b.png",
      }
    },
    slidesFeedback: {
      0: {
        id: 0,
        img: "/img/slider/slider2_18.jpg",
        webp: "/img/slider/slider2_18.webp",
        imgBig: "/img/slider/slider2_18b.jpg",
      },
      1: {
        id: 1,
        img: "/img/slider/slider2_19.jpg",
        webp: "/img/slider/slider2_19.webp",
        imgBig: "/img/slider/slider2_19b.jpg",
      },
      2: {
        id: 2,
        img: "/img/slider/slider2_20.jpg",
        webp: "/img/slider/slider2_20.webp",
        imgBig: "/img/slider/slider2_20b.jpg",
      },
      3: {
        id: 3,
        img: "/img/slider/slider2_21.jpg",
        webp: "/img/slider/slider2_21.webp",
        imgBig: "/img/slider/slider2_21b.jpg",
      },
      4: {
        id: 4,
        img: "/img/slider/slider2_22.jpg",
        webp: "/img/slider/slider2_22.webp",
        imgBig: "/img/slider/slider2_22b.jpg",
      },
      5: {
        id: 5,
        img: "/img/slider/slider2_23.jpg",
        webp: "/img/slider/slider2_23.webp",
        imgBig: "/img/slider/slider2_23b.jpg",
      },
      6: {
        id: 6,
        img: "/img/slider/slider2_24.jpg",
        webp: "/img/slider/slider2_24.webp",
        imgBig: "/img/slider/slider2_24b.jpg",
      },
      7: {
        id: 7,
        img: "/img/slider/slider2_25.jpg",
        webp: "/img/slider/slider2_25.webp",
        imgBig: "/img/slider/slider2_25b.jpg",
      },
      8: {
        id: 8,
        img: "/img/slider/slider2_26.jpg",
        webp: "/img/slider/slider2_26.webp",
        imgBig: "/img/slider/slider2_26b.jpg",
      },
      9: {
        id: 9,
        img: "/img/slider/slider2_27.jpg",
        webp: "/img/slider/slider2_27.webp",
        imgBig: "/img/slider/slider2_27b.jpg",
      },
      10: {
        id: 10,
        img: "/img/slider/slider2_28.jpg",
        webp: "/img/slider/slider2_28.webp",
        imgBig: "/img/slider/slider2_28b.jpg",
      },
      11: {
        id: 11,
        img: "/img/slider/slider2_29.jpg",
        webp: "/img/slider/slider2_29.webp",
        imgBig: "/img/slider/slider2_29b.jpg",
      },
      12: {
        id: 12,
        img: "/img/slider/slider2_30.jpg",
        webp: "/img/slider/slider2_30.webp",
        imgBig: "/img/slider/slider2_30b.jpg",
      },
      13: {
        id: 13,
        img: "/img/slider/slider2_31.jpg",
        webp: "/img/slider/slider2_31.webp",
        imgBig: "/img/slider/slider2_31b.jpg",
      },
      14: {
        id: 14,
        img: "/img/slider/slider2_1.png",
        webp: "/img/slider/slider2_1.webp",
        imgBig: "/img/slider/slider2_1b.png",
      },
      15: {
        id: 15,
        img: "/img/slider/slider2_2.png",
        webp: "/img/slider/slider2_2.webp",
        imgBig: "/img/slider/slider2_2b.png",
      },
      16: {
        id: 16,
        img: "/img/slider/slider2_3.png",
        webp: "/img/slider/slider2_3.webp",
        imgBig: "/img/slider/slider2_3b.png",
      },
      17: {
        id: 17,
        img: "/img/slider/slider2_4.png",
        webp: "/img/slider/slider2_4.webp",
        imgBig: "/img/slider/slider2_4b.png",
      },
      18: {
        id: 18,
        img: "/img/slider/slider2_5.png",
        webp: "/img/slider/slider2_5.webp",
        imgBig: "/img/slider/slider2_5b.png",
      },
      19: {
        id: 19,
        img: "/img/slider/slider2_6.png",
        webp: "/img/slider/slider2_6.webp",
        imgBig: "/img/slider/slider2_6b.png",
      },
      20: {
        id: 20,
        img: "/img/slider/slider2_8.png",
        webp: "/img/slider/slider2_8.png",
        imgBig: "/img/slider/slider2_8b.png",
      },
      21: {
        id: 21,
        img: "/img/slider/slider2_9.png",
        webp: "/img/slider/slider2_9.webp",
        imgBig: "/img/slider/slider2_9b.png",
      },
      22: {
        id: 22,
        img: "/img/slider/slider2_10.png",
        webp: "/img/slider/slider2_10.webp",
        imgBig: "/img/slider/slider2_10b.png",
      },
      23: {
        id: 23,
        img: "/img/slider/slider2_11.png",
        webp: "/img/slider/slider2_11.webp",
        imgBig: "/img/slider/slider2_11b.png",
      },
      24: {
        id: 24,
        img: "/img/slider/slider2_12.png",
        webp: "/img/slider/slider2_12.webp",
        imgBig: "/img/slider/slider2_12b.png",
      },
      25: {
        id: 25,
        img: "/img/slider/slider2_13.png",
        webp: "/img/slider/slider2_13.webp",
        imgBig: "/img/slider/slider2_13b.png",
      },
      26: {
        id: 26,
        img: "/img/slider/slider2_14.png",
        webp: "/img/slider/slider2_14.webp",
        imgBig: "/img/slider/slider2_14b.png",
      },
      27: {
        id: 27,
        img: "/img/slider/slider2_15.png",
        webp: "/img/slider/slider2_15.webp",
        imgBig: "/img/slider/slider2_15b.png",
      },
      28: {
        id: 28,
        img: "/img/slider/slider2_16.png",
        webp: "/img/slider/slider2_16.webp",
        imgBig: "/img/slider/slider2_16b.png",
      },
      29: {
        id: 29,
        img: "/img/slider/slider2_17.png",
        webp: "/img/slider/slider2_17.webp",
        imgBig: "/img/slider/slider2_17b.png",
      },
      30: {
        id: 30,
        img: "/img/slider/slider2_32(1).jpg",
        webp: "/img/slider/slider2_32(1).webp",
        imgBig: "/img/slider/slider2_32b(1).jpg",
      },
      31: {
        id: 31,
        img: "/img/slider/slider2_32(2).jpg",
        webp: "/img/slider/slider2_32(2).webp",
        imgBig: "/img/slider/slider2_32b(2).jpg",
      },
      32: {
        id: 32,
        img: "/img/slider/slider2_32(3).jpg",
        webp: "/img/slider/slider2_32(3).webp",
        imgBig: "/img/slider/slider2_32b(3).jpg",
      },
      33: {
        id: 33,
        img: "/img/slider/slider2_32(4).jpg",
        webp: "/img/slider/slider2_32(4).webp",
        imgBig: "/img/slider/slider2_32b(4).jpg",
      },
      34: {
        id: 34,
        img: "/img/slider/slider2_32(5).jpg",
        webp: "/img/slider/slider2_32(5).webp",
        imgBig: "/img/slider/slider2_32b(5).jpg",
      },
      35: {
        id: 35,
        img: "/img/slider/slider2_32(6).jpg",
        webp: "/img/slider/slider2_32(6).webp",
        imgBig: "/img/slider/slider2_32b(6).jpg",
      },
      36: {
        id: 36,
        img: "/img/slider/slider2_32(7).jpg",
        webp: "/img/slider/slider2_32(7).webp",
        imgBig: "/img/slider/slider2_32b(7).jpg",
      },
      37: {
        id: 37,
        img: "/img/slider/slider2_32(8).jpg",
        webp: "/img/slider/slider2_32(8).webp",
        imgBig: "/img/slider/slider2_32b(8).jpg",
      },
      38: {
        id: 38,
        img: "/img/slider/slider2_32(9).jpg",
        webp: "/img/slider/slider2_32(9).webp",
        imgBig: "/img/slider/slider2_32b(9).jpg",
      },
      39: {
        id: 39,
        img: "/img/slider/slider2_32(10).jpg",
        webp: "/img/slider/slider2_32(10).webp",
        imgBig: "/img/slider/slider2_32b(10).jpg",
      },
      40: {
        id: 40,
        img: "/img/slider/slider2_32(11).jpg",
        webp: "/img/slider/slider2_32(11).webp",
        imgBig: "/img/slider/slider2_32b(11).jpg",
      },
      41: {
        id: 41,
        img: "/img/slider/slider2_32(12).jpg",
        webp: "/img/slider/slider2_32(12).webp",
        imgBig: "/img/slider/slider2_32b(12).jpg",
      },
      42: {
        id: 42,
        img: "/img/slider/slider2_32(13).jpg",
        webp: "/img/slider/slider2_32(13).webp",
        imgBig: "/img/slider/slider2_32b(13).jpg",
      },
      43: {
        id: 43,
        img: "/img/slider/slider2_32(14).jpg",
        webp: "/img/slider/slider2_32(14).webp",
        imgBig: "/img/slider/slider2_32b(14).jpg",
      },
      44: {
        id: 44,
        img: "/img/slider/slider2_32(15).jpg",
        webp: "/img/slider/slider2_32(15).webp",
        imgBig: "/img/slider/slider2_32b(15).jpg",
      },
      45: {
        id: 45,
        img: "/img/slider/slider2_32(16).jpg",
        webp: "/img/slider/slider2_32(16).webp",
        imgBig: "/img/slider/slider2_32b(16).jpg",
      },
      46: {
        id: 46,
        img: "/img/slider/slider2_32(17).jpg",
        webp: "/img/slider/slider2_32(17).webp",
        imgBig: "/img/slider/slider2_32b(17).jpg",
      },
      47: {
        id: 47,
        img: "/img/slider/slider2_32(18).jpg",
        webp: "/img/slider/slider2_32(18).webp",
        imgBig: "/img/slider/slider2_32b(18).jpg",
      }
    },
    slidesVideo: {
      0: {
        id: 0,
        video: "https://www.youtube.com/embed/dvHnj6r6yNI",
        img: "img/video_1.jpg",
      }
    },
    slidesVideo2: {
      0: {
        id: 0,
        video: "https://www.youtube.com/embed/Y_tlJfIyH0U",
        img: "img/video_2.jpg",
        title: "Чистка подушек"
      },
      1: {
        id: 1,
        video: "https://www.youtube.com/embed/73RuOhrV-X4",
        img: "img/video_3.jpg",
        title: "Пылевыбивальный станок"
      },
      2: {
        id: 2,
        video: "https://youtu.be/4XHVD-TfOoA",
        img: "img/video_4.jpg",
        title: "Стирка ковров в Чите"
      }
    }
  },
  components: {
    "carousel-3d": Carousel3d.Carousel3d,
    slide: Carousel3d.Slide,
  },
  methods: {
    onSlideClick() {
      alert("Остановись слайдер!!!");
      this.isAutoplay = false;
    },
  },
});



$().fancybox({
  selector: ".slider__link--portfolio:visible",
  loop: true,
  btnTpl: {
    arrowLeft:
      '<button id="prev" data-fancybox-prev class="fancybox-button fancybox-button--arrow_left" title="Назад"></button>',
    arrowRight:
      '<button id ="next" data-fancybox-next class="fancybox-button fancybox-button--arrow_right" title="Вперед"></button>',
  },
});

$().fancybox({
  selector: ".slider__link--reviews:visible",
  loop: true,
  btnTpl: {
    arrowLeft:
      '<button id="prev" data-fancybox-prev class="fancybox-button fancybox-button--arrow_left" title="Назад"></button>',
    arrowRight:
      '<button id ="next" data-fancybox-next class="fancybox-button fancybox-button--arrow_right" title="Вперед"></button>',
  },
});
