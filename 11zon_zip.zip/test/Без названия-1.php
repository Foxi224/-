<?php
   foreach($data as $item){
    ?>
    <div class="news">
        <div class="phone"><?php echo $item[1] ?></div>
        <div class="model"><?php echo $item[2] ?></div>
        <div class="edinich"><?php echo $item[3] ?></div>
        <div class="btns">
            <a href="edit.php?id=<?php echo $item[0] ?>">Редактировать</a>
            <a href="delite.php?id=<?php echo $item[0] ?>">Удалить</a>
        </div>
    </div>
    <?php
   }
   ?>