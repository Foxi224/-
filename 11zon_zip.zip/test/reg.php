<?php
$login = $_POST['login-reg'];
$pass = $_POST['pass-reg'];
// echo $login.$pass;

$mysql = new mysqli('localhost', 'root', '','test-reg');
$result = $mysql->query("SELECT * FROM users WHERE login = '$login'");
$users = $result->fetch_assoc();
if(!empty($users)){
    echo 'Логин уже используется!';
    exit();
}
$mysql->query("INSERT INTO users (`login`,`password`) VALUES ('$login','$pass')");
echo "Пользователь ".$login." зарегистрирован!";
$mysql->close();
?>