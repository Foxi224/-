<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Document</title>
</head>

<body>
    <div class="reg_form">
        <h1>Форма Регистрации</h1>
        <form action="reg.php" method="POST">
            <input type="text" placeholder="Введите логин" id="login-reg" name="login-reg">
            <input type="text" placeholder="ВВедите пароль" id='pass-reg' name="pass-reg">
            <button>Зарегистрироваться</button>
        </form>
        
    </div>

    <div class="login_form">
        <h1>Форма авторизации</h1>
        <form action="Login.php" method="POST">
            <input type="text" placeholder="Введите логин" id="login-log" name="login-log">
            <input type="text" placeholder="ВВедите пароль" id='pass-log' name="pass-log">
            <button>Войти</button>
        </form>
    </div>

</body>

</html>