<?php

$id = $_POST['id'];
$name = $_POST['name'];
$model = $_POST['model'];
$prise = $_POST['prise'];
$discription = $_POST['discription'];

$mysql = new mysqli('localhost', 'root', '','php');

$result = $mysql->query("INSERT INTO `telefon`(`name`, `model`, `prise`, `description`) VALUES
('$name','$model','$prise','$description')");

header('Location: /hello.php');