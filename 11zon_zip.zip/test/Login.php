<?php

use LDAP\Result;

$login = $_POST['login-log'];
$pass = $_POST['pass-log'];

$mysql = new mysqli('127.0.0.1','root','','php','3307');

$result = $mysql->query("SELECT * FROM users WHERE login='$login' AND password='$pass'");
$user = $result->fetch_assoc();

if(empty($user)){
    echo "Введен неверный логин или пароль";
}else{
    $mysql->close();
    header('Location: hello.php');
}

?>