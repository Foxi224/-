<?php
$id = $_POST['id'];
$name = $_POST['name'];
$model = $_POST['model'];
$prise = $_POST['prise'];
$discription = $_POST['discription'];


$mysql = new mysqli('localhost', 'root', '','php');

$result = $mysql->query("UPDATE `telefon` SET `id`='$id',`name`='$name',`model`='$model',`prise`='$prise',`description`='$description' WHERE `id`='$id'");

header('Location: /hello.php');