<?php

$id = $_GET['id'];

$mysql = new mysqli('localhost', 'root', '','php');

$result = $mysql->query("SELECT * FROM `telefon` WHERE `id` = '$id'");
$data = $result->fetch_assoc();
// print_r($data);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="edit-script.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $data['id'] ?>">
        <input type="text" placeholder="Введите название цацки"  value="<?php echo $data['name'] ?>"  name="name">
        <input type="text" placeholder="Введите номер образины"  value="<?php echo $data['model'] ?>"  name="model">
        <input type="text" placeholder="Введите балдёжную цену"  value="<?php echo $data['prise'] ?>"  name="prise">
        <input type="text" placeholder="Введите всякую дичь для покупателя" value="<?php echo $data['description'] ?>"  name="discription">
        
        <button>Обновить</button>
    </form>
    
</body>
</html>