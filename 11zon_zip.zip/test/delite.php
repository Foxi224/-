<?php

$id = $_GET['id'];

$mysql = new mysqli('localhost', 'root', '','php');

$result = $mysql->query("DELETE FROM telefon WHERE `telefon`.`id` = '$id'");

header('Location: /hello.php')

?>